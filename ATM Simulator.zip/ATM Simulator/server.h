#ifndef SERVER_H_INCLUDED
#define SERVER_H_INCLUDED
struct date
{
    int month,day,year;

};
struct
{

    char name[60];
    int acc_no,age;
    int pin;
    char address[60];
    char citizenship[15];
    double phone;
    char acc_type[10];
    float amt;
    struct date dob;
    struct date deposit;
    struct date withdraw;

}add,upd,check,rem,transaction;
void gotoxy(int x, int y);
void load();
void menu();
float interest(float t,float amount,int rate);
void fordelay(int j);
void new_acc();
void view_list();
void edit(void);
void transact(void);
void erase_(void);
void see(void);
void close(void);
void menu(void);


#endif // SERVER_H_INCLUDED
